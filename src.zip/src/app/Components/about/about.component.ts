/**  DEVELOPED BY - AISHWARYA SARNA
 *  DATE OF CREATION - 10/10/2019
 *  ABOUT COMPONENT 
 * 
*/


import { Component, OnInit } from '@angular/core';


//decorator
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})

//AboutComponent Class
export class AboutComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }
}


