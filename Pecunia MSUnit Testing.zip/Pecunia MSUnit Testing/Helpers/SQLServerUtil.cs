﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.Pecunia.Helpers
{
   public class SQLServerUtil
   {
        public static SqlConnection getConnection(string serverName, string databaseName, string user, string password)
        {
            string connectionString = $"Data Source={serverName}; Initial Catalog={databaseName}; User ID={user}; Password={password}";
            SqlConnection conn = new SqlConnection(connectionString);

            return conn;
        }
   }
}
