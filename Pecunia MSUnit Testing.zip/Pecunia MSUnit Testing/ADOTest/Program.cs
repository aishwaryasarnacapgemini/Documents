﻿using Capgemini.Pecunia.Helpers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Capgemini.Pecunia.ADOTest
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conn = SQLServerUtil.getConnection("ndamssql\\sqlilearn", "13th Aug Cloud PT Immersive", "sqluser", "sqluser");
            try
            {
   
                SqlCommand sqlCommand = new SqlCommand("TeamF.AddEmployees", conn);
                
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
